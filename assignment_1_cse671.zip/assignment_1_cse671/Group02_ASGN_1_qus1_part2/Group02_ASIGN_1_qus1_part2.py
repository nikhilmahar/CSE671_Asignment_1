
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 15 11:54:52 2023

@author: Group2
"""
import numpy as np
from numpy import random
import matplotlib.pyplot as plt
from sklearn.utils import shuffle

def sigmoid(a,mu):
    f=1/(1+np.exp(-1*a))
    return f

def del0(label,pred):
    dfda=pred*(1-pred)
    del_0=(label-pred)*dfda
    return del_0
    

record=np.loadtxt("NLS_Group02.txt")
class1_input = record[0:499,:]
class2_input = record[500:999,:]
class3_input = record[1000:,:]
plt.scatter(class1_input[:,0],class1_input[:,1])
plt.scatter(class2_input[:,0],class2_input[:,1])
plt.scatter(class3_input[:,0],class3_input[:,1])
plt.show()
M=3   #total number of classes
N=int(M*(M-1)/2 )    #Total nuber of perceptrons
#training data
train_number1=int(len(class1_input)*70/100)
train_number2=int(len(class2_input)*70/100)
train_number3=int(len(class3_input)*70/100)
class1_train=class1_input[0:train_number1,:]
class2_train=class2_input[0:train_number2,:]
class3_train=class3_input[0:train_number3,:]
#training labels
class1_label=np.ones((len(class1_train),1))
class2_label=np.ones((len(class2_train),1))
class3_label=np.ones((len(class3_train),1))
#training labels for N12
class12_label=np.concatenate((class1_label,0*class2_label),0)
#training labels for N13
class13_label=np.concatenate((class1_label,0*class3_label),0)
#training labels for N23
class23_label=np.concatenate((class2_label,0*class3_label),0)

#training data for N12 Perceptron
class12_train=np.concatenate((class1_train,class2_train),0)
class12_train=np.concatenate((np.ones((len(class12_train),1)),class12_train),1)     #to include bias term
#training data for N13 Perceptron
class13_train=np.concatenate((class1_train,class3_train),0)
class13_train=np.concatenate((np.ones((len(class13_train),1)),class13_train),1)         #to include bias term
#training data for N23 Perceptron
class23_train=np.concatenate((class2_train,class3_train),0)
class23_train=np.concatenate((np.ones((len(class23_train),1)),class23_train),1)     #to include bias term

N12_train=np.zeros((len(class12_train),3))
N13_train=np.zeros((len(class13_train),3))
N23_train=np.zeros((len(class23_train),3))




# =============================================================================
# Training of N13 starts
# =============================================================================

#weights initilization
w12=[1,1,1]
# w12 = random.rand(1, 3)
w13 = random.rand(1, 3)
w23 = random.rand(1, 3)
average_train_loss_N12=[]
average_train_loss_N13=[]
average_train_loss_N23=[]
#learning rate
mu=0.001
epochs=50;
# y_pred=np.zeros((len(class12_label),1))
for epoch in range(epochs):
    # =============================================================================
    # Shuffle training inputs and labels
    # =============================================================================
    N12_train,N12_label=shuffle(class12_train,class12_label)
    N13_train,N13_label=shuffle(class13_train,class13_label)
    N23_train,N23_label=shuffle(class23_train,class23_label)
    
    # y_pred_N12=[]
    loss_N12=[]
    # y_pred_N13=[]
    loss_N13=[]
    # y_pred_N23=[]
    loss_N23=[]
    i=0;
    # print(epoch,y_pred.shape)
    for (data_N13,data_N23) in zip(N13_train,N23_train):
        # data_N12=data_N12.reshape(3,1)
        data_N13=data_N13.reshape(3,1)
        data_N23=data_N23.reshape(3,1)
        # linear function w.x
        # y_pred_N12=np.dot(w12,data_N12)
        # f_pred_N12=sigmoid(y_pred_N12, mu)
        # y_out_N12=np.array(f_pred_N12)
        y_pred_N13=np.dot(w13,data_N13)
        f_pred_N13=sigmoid(y_pred_N13, mu)
        y_out_N13=np.array(f_pred_N13)
        y_pred_N23=np.dot(w23,data_N23)
        f_pred_N23=sigmoid(y_pred_N23, mu)
        y_out_N23=np.array(f_pred_N23)
        

        # np.array(y_out_N12).reshape(1,1)
        np.array(y_out_N13).reshape(1,1)
        np.array(y_out_N23).reshape(1,1)
        # loss_N12.append(0.5*(y_out_N12-N12_label[i,0])**2)
        loss_N13.append(0.5*(y_out_N13-N13_label[i,0])**2)
        loss_N23.append(0.5*(y_out_N23-N23_label[i,0])**2)
        # del_0_N12=del0(N12_label[i,0],y_out_N12)
        del_0_N13=del0(N13_label[i,0],y_out_N13)
        del_0_N23=del0(N23_label[i,0],y_out_N23)
        # delta_w12=mu*del_0_N12*data_N12
        delta_w13=mu*del_0_N13*data_N13
        delta_w23=mu*del_0_N23*data_N23
        i=i+1
        # w12=w12+delta_w12.T
        w13=w13+delta_w13.T
        w23=w23+delta_w23.T
        # print( "del0",del_0_N12,"y_out",y_out_N12)
        # print(loss)
        j=0;
        for (data_N12) in (N12_train):
            
            data_N12=data_N12.reshape(3,1)
            # linear function w.x
            y_pred_N12=np.dot(w12,data_N12)
            f_pred_N12=sigmoid(y_pred_N12, mu)
            y_out_N12=np.array(f_pred_N12)
            

            np.array(y_out_N12).reshape(1,1)
            loss_N12.append(0.5*(y_out_N12-N12_label[j,0])**2)
            del_0_N12=del0(N12_label[j,0],y_out_N12)
            delta_w12=mu*del_0_N12*data_N12
            j=j+1
            w12=w12+delta_w12.T
        
    average_loss_N12=np.mean(loss_N12)
    average_loss_N13=np.mean(loss_N13)
    average_loss_N23=np.mean(loss_N23)
    average_train_loss_N12.append(average_loss_N12)
    average_train_loss_N13.append(average_loss_N13)
    average_train_loss_N23.append(average_loss_N23)
    print("epoch:",epoch,"|avg training loss of N12:",average_loss_N12)
    print("epoch:",epoch,"|avg training loss of N13:",average_loss_N13)
    print("epoch:",epoch,"|avg training loss of N23:",average_loss_N23)



# =============================================================================
# Testing of N12 ,N13,N23 Perceptron
# =============================================================================
    
#testing data
# train_number=int(len(class1_input)*70/100)
class1_test=class1_input[train_number1:len(class1_input),:]
class2_test=class2_input[train_number2:len(class2_input),:]
class3_test=class3_input[train_number3:len(class3_input),:]
#test labels
class1_test_label=np.ones((len(class1_test),1))
class2_test_label=np.ones((len(class2_test),1))
class3_test_label=np.ones((len(class3_test),1))
#test labels for N12
class12_test_label=np.concatenate((class1_test_label,0*class2_test_label),0)
#test labels for N13
class13_test_label=np.concatenate((class1_test_label,0*class3_test_label),0)
#training labels for N23
class23_test_label=np.concatenate((class2_test_label,0*class3_test_label),0)

#testing data for N12 Perceptron
class12_test=np.concatenate((class1_test,class2_test),0)
class12_test=np.concatenate((np.ones((len(class12_test),1)),class12_test),1)     #to include bias term

#test data for N13 Perceptron
class13_test=np.concatenate((class1_test,class3_test),0)
class13_test=np.concatenate((np.ones((len(class13_test),1)),class13_test),1)         #to include bias term

#test data for N23 Perceptron
class23_test=np.concatenate((class2_test,class3_test),0)
class23_test=np.concatenate((np.ones((len(class23_test),1)),class23_test),1)     #to include bias term
      
y_test_N12_pred=[]
y_test_N13_pred=[]
y_test_N23_pred=[]
test_loss_N12=[]
test_loss_N13=[]
test_loss_N23=[]
i=0;
Y_test_N12=[]
Y_test_N13=[]
Y_test_N23=[]
    # print(epoch,y_pred.shape)
for (data_N13,data_N23) in zip(class13_test,class23_test):
    # data_N12=data_N12.reshape(3,1)
    data_N13=data_N13.reshape(3,1)
    data_N23=data_N23.reshape(3,1)
    # linear function w.x
    # y_test_N12_pred=np.dot(w12,data_N12)
    # y_test_N12_pred=sigmoid(y_test_N12_pred,mu)
    y_test_N13_pred=np.dot(w13,data_N13)
    y_test_N13_pred=sigmoid(y_test_N13_pred, mu)
    y_test_N23_pred=np.dot(w23,data_N23)
    y_test_N23_pred=sigmoid(y_test_N23_pred, mu)
    y_test_N12_pred=np.array(y_test_N12_pred)
    y_test_N13_pred=np.array(y_test_N13_pred)
    y_test_N23_pred=np.array(y_test_N23_pred)
    

    # np.array(y_test_N12_pred).reshape(1,1)
    np.array(y_test_N13_pred).reshape(1,1)
    np.array(y_test_N23_pred).reshape(1,1)
    # test_loss_N12.append(0.5*(y_test_N12_pred-class12_test_label[i,0])**2)
    test_loss_N13.append(0.5*(y_test_N13_pred-class13_test_label[i,0])**2)
    test_loss_N23.append(0.5*(y_test_N23_pred-class23_test_label[i,0])**2)
    
    
# =============================================================================
#         discreminant function starts
# =============================================================================
    if y_test_N13_pred>0.5 :
        y_test_N13_pred=1.0
    if y_test_N23_pred>0.5:
        y_test_N23_pred=1.0
    if y_test_N13_pred<=0.5 :
        y_test_N13_pred=0.0
    if y_test_N23_pred<=0.5:
        y_test_N23_pred=0.0           
# =============================================================================
#             descreminant function ends
# =============================================================================
    Y_test_N13.append(y_test_N13_pred)
    Y_test_N23.append(y_test_N23_pred)
    i=i+1
Y_test_N13=np.array(Y_test_N13).reshape(class13_test_label.shape)
Y_test_N23=np.array(Y_test_N23).reshape(class23_test_label.shape)
    
j=0;
for (data_N12) in (class12_test):
    data_N12=data_N12.reshape(3,1)
   
    # linear function w.x
    y_test_N12_pred=np.dot(w12,data_N12)
    y_test_N12_pred=sigmoid(y_test_N12_pred,mu)
    np.array(y_test_N12_pred).reshape(1,1)
    test_loss_N12.append(0.5*(y_test_N12_pred-class12_test_label[j,0])**2)
    
    
# =============================================================================
#         discreminant function starts
# =============================================================================
    if y_test_N12_pred>0.5:
        y_test_N12_pred=1.0
    if y_test_N12_pred<=0.5 :
        y_test_N12_pred=0.0
        
    

           
# =============================================================================
#             descreminant function ends
# =============================================================================
    Y_test_N12.append(y_test_N12_pred)
    j=j+1
Y_test_N12=np.array(Y_test_N12).reshape(class12_test_label.shape)
    
    
average_test_loss_N12=np.mean(test_loss_N12)
average_test_loss_N13=np.mean(test_loss_N13)
average_test_loss_N23=np.mean(test_loss_N23)

print("average test loss for N12",average_test_loss_N12)   
print("average test loss for N13",average_test_loss_N13) 
print("average test loss for N23",average_test_loss_N23) 

# =============================================================================
# confusion matrix
# =============================================================================
def compute_confusion_matrix(true, pred):
  K = len(np.unique(true)) # Number of classes 
  result = np.zeros((K, K))

  for i in range(len(true)):
    result[int(true[i])][int(pred[i])] += 1

  return result
    
confusion_mat_N12=compute_confusion_matrix(class12_test_label, Y_test_N12)    
confusion_mat_N13=compute_confusion_matrix(class13_test_label, Y_test_N13) 
confusion_mat_N23=compute_confusion_matrix(class23_test_label, Y_test_N23) 

c11=confusion_mat_N12[0,0]+confusion_mat_N13[0,0]
c12=confusion_mat_N12[0,1]
c21=confusion_mat_N12[1,0]
c22=confusion_mat_N12[1,1]+confusion_mat_N23[0,0]
c13=confusion_mat_N13[0,1]
c31=confusion_mat_N13[1,0]
c33=confusion_mat_N13[1,1]
c23=confusion_mat_N23[0,1]
c32=confusion_mat_N23[1,0]

multiclass_confusion_matrix=np.array([[c11, c12, c13],
                   [c21, c22, c23],
                   [c31, c32,c33]])

accuracy=(c11+c22+c33)/sum(sum(multiclass_confusion_matrix))*100;



# =============================================================================
# 
# =============================================================================

# =============================================================================
# plot decision boundary for N12, N13, N23   
# =============================================================================
        
x=np.linspace(-10, 10,300)
y=np.linspace(-10, 10,300)
X1,Y1=np.meshgrid(x, y)
X=X1.flatten()
X=X.reshape(len(X),1)
Y=Y1.flatten()
Y=Y.reshape(len(Y),1)
ONE=np.ones((len(X),1))
XY_TEST=np.concatenate((ONE,X,Y),1)
Y_N12=[]
Y_N13=[]
Y_N23=[]
# print(epoch,y_pred.shape)
for (xy_data) in (XY_TEST):
    xy_data=xy_data.reshape(3,1)
    # linear function w.x
    y_pred_N12=np.dot(w12,xy_data)
    y_out_N12=sigmoid(y_pred_N12, mu)
    y_pred_N13=np.dot(w13,xy_data)
    y_out_N13=sigmoid(y_pred_N13, mu)
    y_pred_N23=np.dot(w23,xy_data)
    y_out_N23=sigmoid(y_pred_N23, mu)
    
# =============================================================================
#         discreminant function starts
# =============================================================================
    # if y_out_N12>0.5:
    #     y_out_N12=1.0
    # if y_out_N13>0.5 :
    #     y_out_N13=1.0
    # if y_out_N23>0.5:
    #     y_out_N23=1.0
    # if y_out_N12<=0.5 :
    #     y_out_N12=0.0
    # if y_out_N13<=0.5 :
    #     y_out_N13=0.0
    # if y_out_N23<=0.5:
    #     y_out_N23=0.0
    if y_out_N12>0.5:
        y_out_N12=2
    if y_out_N12<=0.5 :
        y_out_N12=1
    if y_out_N13>0.5 :
        y_out_N13=3
    if y_out_N13<=0.5 :
        y_out_N13=1
    if y_out_N23>0.5:
          y_out_N23=3
    if y_out_N23<=0.5:
          y_out_N23=2

       
# =============================================================================
#             descreminant function ends
# =============================================================================
    Y_N12.append(y_out_N12)
    Y_N13.append(y_out_N13)
    Y_N23.append(y_out_N23)

Y_N12=np.array(Y_N12).reshape(X1.shape)
Y_N13=np.array(Y_N13).reshape(X1.shape)
Y_N23=np.array(Y_N23).reshape(X1.shape)




plt.contourf(X1,Y1,Y_N12)
plt.scatter(class1_input[:,0],class1_input[:,1])
plt.scatter(class2_input[:,0],class2_input[:,1])
plt.xlabel("feature x")
plt.ylabel("feature y")
plt.show()

plt.contourf(X1,Y1,Y_N13)
plt.scatter(class1_input[:,0],class1_input[:,1])
plt.scatter(class3_input[:,0],class3_input[:,1])
plt.xlabel("feature x")
plt.ylabel("feature y")
plt.show()

plt.contourf(X1,Y1,Y_N23)
plt.scatter(class2_input[:,0],class2_input[:,1])
plt.scatter(class3_input[:,0],class3_input[:,1])
plt.xlabel("feature x")
plt.ylabel("feature y")
plt.show()


#FLATTEN
Y_N12,Y_N13,Y_N23=Y_N12.flatten(),Y_N13.flatten(),Y_N23.flatten()
fd=[]
for (val_n12,val_n13,val_n23) in zip(Y_N12,Y_N13,Y_N23):
    count1=0;
    count2=0;
    count3=0;
    arr=[]
    if val_n12==1:
        count1+=1;
    if val_n13==1:
        count1+=1;
    if val_n23==1:
        count2+=1;
    if val_n12==2:
        count2+=1;
    if val_n13==3:
        count3+=1;
    if val_n23==2:
        count2+=1;
    if val_n23==3:
        count3+=1;
    arr=[count1,count2,count3]
    max_count_index=arr.index(max(arr))
    fd.append(max_count_index+1)
    # print("COUNT1",count1,"count2",count2,"count3",count3,"fd",fd)
        
fd=np.array(fd).reshape(X1.shape)
plt.contourf(X1,Y1,fd)
plt.xlabel("feature x")
plt.ylabel("feature y")
plt.scatter(class1_input[:,0],class1_input[:,1])
plt.scatter(class2_input[:,0],class2_input[:,1])
plt.scatter(class3_input[:,0],class3_input[:,1])
plt.show()

plt.plot(average_train_loss_N12)
plt.plot(average_train_loss_N13)
plt.plot(average_train_loss_N23)
plt.xlabel("epoch")
plt.ylabel("training loss")
plt.legend(["N12-LOSS","N13-LOSS","N23-LOSS"])
plt.show()
















