
import numpy as np
from numpy import random
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d  
from sklearn.utils import shuffle
record=np.loadtxt("2.csv", delimiter=',')
input1 =record[:,0:2] #.reshape((len(record),2))
target=record[:,2].reshape((len(record),1))
#training data
train_number=int(len(input1)*70/100)
input_train=input1[0:train_number,:]
# input_train=input_train.reshape((len(input_train),1))
input_train=np.concatenate((np.ones((len(input_train),1)),input_train),1)

#training labels
target_train=target[0:train_number,:]
target_train=target_train.reshape((len(target_train),1))


# =============================================================================
# Training of N13 starts
# =============================================================================

#weights initilization
w1 = random.rand(1, 3)
# w1=[0,0]
# w2 = random.rand(1, 2)
# w23 = random.rand(1, 3)
#learning rate
mu=0.001
epochs=100;
# y_pred=np.zeros((len(class12_label),1))
train_lpe=[]
train_avg=[]
train_lpe_avg=[]
for epoch in range(epochs):
    # =============================================================================
    # Shuffle training inputs and labels
    # =============================================================================
    from sklearn.utils import shuffle
    input_train,target_train=shuffle(input_train,target_train)
    train_loss=[]
    train_pred=[]
    i=0;
    for (data) in (input_train):
        data=data.reshape(3,1)
        # linear function w.x
        y_pred=np.dot(w1,data)
        y_pred=np.array(y_pred).reshape(1,1)
        train_loss.append(0.5*(target_train[i,0]-y_pred)**2)
        train_avg.append((target_train[i,0]-y_pred))
        delta_w1=mu*(target_train[i,0]-y_pred)*data
        i=i+1
        w1=w1+delta_w1.T
        train_pred.append(y_pred)
        
        # print(loss)
    average_loss=np.mean(train_loss)
    train_lpe.append(average_loss)
    train_lpe_avg.append(np.mean(train_avg))
    print("epoch:",epoch,"|avg training loss:",average_loss,"|")
    



# =============================================================================
# Testing of N12 ,N13,N23 Perceptron
# =============================================================================
    
#testing data

input_test=input1[train_number:len(input1),:]
# input_test=input_test.reshape((len(input_test),1))
input_test=np.concatenate((np.ones((len(input_test),1)),input_test),1)

#test labels
target_test=target[train_number:,:]
target_test=target_test.reshape((len(target_test),1))


# =============================================================================
# Shuffle training inputs and labels
# =============================================================================
from sklearn.utils import shuffle
input_test,target_test=shuffle(input_test,target_test)
test_loss=[]
test_pred=[]
i=0;
for (data) in (input_test):
    data=data.reshape(3,1)
    # linear function w.x
    y_test=np.dot(w1,data)
    y_test=np.array(y_test).reshape(1,1)
    test_loss.append(0.5*(target_test[i,0]-y_test)**2)
    test_pred.append(y_test)
   
average_train_loss=np.mean(train_loss)
average_test_loss=np.mean(test_loss)


print("epoch:",epoch,"|avg test loss:",average_test_loss,"|")

fig = plt.figure(figsize = (10, 7))  
ax = plt.axes(projection ="3d")    
ax.scatter3D(input1[:,0],input1[:,1], target, color = "blue")  


fig = plt.figure(figsize = (10, 7))  
ax = plt.axes(projection ="3d")    
ax.scatter3D(input_test[:,0],input_test[:,1], np.array(test_pred).reshape(len(test_pred),1), color = "orange")

# Creating figures for the plot  
fig = plt.figure(figsize = (10, 7))  
ax = plt.axes(projection ="3d")    
ax.scatter3D(input_test[:,0],input_test[:,1], target_test, color = "blue")  
ax.scatter3D(input_test[:,0],input_test[:,1], np.array(test_pred).reshape(len(test_pred),1), color = "orange")
plt.xlabel("feature 1")
plt.ylabel("feature 2")
plt.legend(["true","pred"])
plt.title("target vs test pred")




fig = plt.figure(figsize = (10, 7))  
ax = plt.axes(projection ="3d")    
ax.scatter3D(input_train[:,0],input_train[:,1], target_train, color = "blue")  
ax.scatter3D(input_train[:,0],input_train[:,1], np.array(train_pred).reshape(len(train_pred),1), color = "orange")
plt.xlabel("feature 1")
plt.ylabel("feature 2")
plt.legend(["true","pred"])
plt.title("target vs train pred")


fig = plt.figure(figsize = (10, 7))  
test_pred1=np.array(test_pred).reshape(target_test.shape)
plt.scatter(target_test,test_pred1)
plt.xlabel("Test target")
plt.ylabel("model output")
plt.title("Model output vs Test target")
plt.show()

fig = plt.figure(figsize = (10, 7))  
train_pred1=np.array(train_pred).reshape(target_train.shape)
plt.scatter(target_train,train_pred1,color="orange")
plt.xlabel("Training target")
plt.ylabel("model output")
plt.title("Model output vs Training target")
plt.show()

fig = plt.figure(figsize = (10, 7))  
plt.plot(np.array(train_lpe).reshape(len(train_lpe),1))
# plt.legend("Training loss")
plt.title("MSE vs epochs")
plt.xlabel("epochs")
plt.ylabel("Training loss")
plt.show()

fig = plt.figure(figsize = (10, 7))  
plt.plot(np.array(train_lpe_avg).reshape(len(train_lpe_avg),1))
# plt.legend("Training loss")
plt.title("Average loss vs epochs")
plt.xlabel("epochs")
plt.ylabel("Training loss")
plt.show()

# creating the dataset
data = {'Average train loss':average_train_loss, 'Average test Loss': average_test_loss}
loss_name = list(data.keys())
values = list(data.values())
  
fig = plt.figure(figsize = (10, 5))
 
# creating the bar plot
plt.bar(loss_name, values, color ='maroon',
        width = 0.4)
 


